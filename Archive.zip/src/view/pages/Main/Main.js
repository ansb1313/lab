import React from "react";
import styled from "styled-components";
import MainContainer from "../../Container/MainContainer";

const Main = (props) => {

  return(
    <Container>
      <MainContainer/>
    </Container>
  )
}

const Container = styled.div`
`

export default Main