import icon from './';

const sideMenuMusic = "https://yt3.ggpht.com/Q3Zd5avmFu7WvZiEgWjjTt09r_Hfxp69EZXoEppkxEtSPdAUt6Q7IH7MpCESnf3wEtxhbUDOLg=s88-c-k-c0x00ffffff-no-rj"

const Images = {
    icon,
    sideMenuMusic
}

export default Images;

